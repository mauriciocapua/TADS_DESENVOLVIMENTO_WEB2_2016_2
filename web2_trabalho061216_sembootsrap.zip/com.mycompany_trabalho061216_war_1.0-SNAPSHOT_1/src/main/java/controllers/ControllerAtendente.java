package controllers;

import java.util.ArrayList;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import model.Atendente;
import model.AtendenteDAO;
import model.Cliente;
import model.ClienteDAO;
import model.Compra;
import model.CompraDAO;
import model.Produto;
import model.ProdutoDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author Mauricio Capua
 */
@Controller
@RequestMapping("/atendente")
public class ControllerAtendente {

    private AtendenteDAO atendenteDAO;
    private ClienteDAO clienteDAO;
    private ProdutoDAO produtoDAO;
    private CompraDAO compraDAO;

//    @Autowired
//    ControllerAtendente(AtendenteDAO atendenteDAO) {
//        this.atendenteDAO = atendenteDAO;
//    }
    @Autowired
    public ControllerAtendente(AtendenteDAO atendenteDAO, ClienteDAO clienteDAO, ProdutoDAO produtoDAO, CompraDAO compraDAO) {
        this.atendenteDAO = atendenteDAO;
        this.clienteDAO = clienteDAO;
        this.produtoDAO = produtoDAO;
        this.compraDAO = compraDAO;
    }

    @RequestMapping("loginForm")
    public String loginForm() {
        return "formulario-login";
    }

    @RequestMapping("efetuaLogin")
    public String efetuaLogin(Atendente atendente, HttpSession session) throws Exception {
        if (atendenteDAO.verificaLogin(atendente) != null) {
            atendente = atendenteDAO.verificaLogin(atendente);
            session.setAttribute("atendenteLogado", atendente);
            return "redirect:/";
        }
        return "formulario-login";
    }

    @RequestMapping("logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/";
    }

    @RequestMapping("efetuarCompra")
    public String compra(Model model, Cliente cliente, HttpServletRequest request) {
        if (request.getParameterValues("List") != null) {
            Compra compra = compraDAO.inserir(cliente);
            ArrayList<Produto> produtos = new ArrayList<>();
            String select[] = request.getParameterValues("List");
            for (String select1 : select) {
                produtos.add(produtoDAO.listarProduto(new Produto(Integer.parseInt(select1))));
            }

            for (int i = 0; i < produtos.size(); i++) {
                System.out.println(produtos.get(i).getDescricao());
            }
        }

        return "redirect:/";
    }

    @RequestMapping("iniciaCompra")
    public String iniciaCompra(Model model) throws Exception {

        List<Cliente> vetCliente = clienteDAO.listarTodos();
//        List<Produto> vetProduto = produtoDAO.listarTodos();
        model.addAttribute("vetCliente", vetCliente);
//        model.addAttribute("vetProduto", vetProduto);
        return "/compras/selecionaCliente";
    }

    @RequestMapping("selecionarProdutos")
    public String selecionarProdutos(Cliente cliente, Model model) throws Exception {

        List<Produto> vetProduto = produtoDAO.listarTodos();
        model.addAttribute("Cliente", cliente);
        model.addAttribute("vetProduto", vetProduto);
        return "/compras/novaCompra";
    }

    @RequestMapping("listarCompras")
    public String listarCompras(Cliente cliente, Model model) throws Exception {
        List<Compra> vetCompra = compraDAO.listarCompras(cliente);
        for (int i = 0; i < vetCompra.size(); i++) {
            vetCompra.get(i).setItens(compraDAO.listarItens(vetCompra.get(i)));
        }
        model.addAttribute("Cliente", cliente);
        model.addAttribute("vetCompra", vetCompra);
        return "/compras/listarCompras";
    }

}
