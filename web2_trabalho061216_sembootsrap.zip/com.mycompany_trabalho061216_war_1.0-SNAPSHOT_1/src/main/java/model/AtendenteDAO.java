/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import Auxiliar.StringUtil;
import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

/**
 *
 * @author Mauricio Capua
 */
@Repository
public class AtendenteDAO {

    private Connection connection;

    @Autowired
    public AtendenteDAO(DataSource dataSource) {
        try {
            this.connection = dataSource.getConnection();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Atendente verificaLogin(Atendente atendente) {
        try {
            String sql = "SELECT * FROM atendente where login=? and senha=?";
            PreparedStatement sqlSelect = connection.prepareStatement(sql);
            sqlSelect.setString(1, atendente.getLogin());
            sqlSelect.setString(2, StringUtil.encripta(atendente.getSenha()));
            ResultSet rs = sqlSelect.executeQuery();
            Atendente aten = null;
            while (rs.next()) {
                aten = new Atendente();
                aten.setId(rs.getInt("id"));
                aten.setNome(rs.getString("nome"));
                aten.setLogin(rs.getString("login"));
                aten.setSenha(rs.getString("senha"));
            }
            sqlSelect.close();
            return aten;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

}
